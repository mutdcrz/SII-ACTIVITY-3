using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Angelo
{
    public sealed class UserAccount
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
    }

    internal static class Database
    {
        private static string LocateDatabase()
        {
            string configured = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Users.accdb");
            if (File.Exists(configured)) return configured;
            DirectoryInfo directory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            while (directory != null)
            {
                string candidate = Path.Combine(directory.FullName, "Users.accdb");
                if (File.Exists(candidate)) return candidate;
                directory = directory.Parent;
            }
            throw new FileNotFoundException("Users.accdb was not found.");
        }

        public static bool TestConnection()
        {
            using (OleDbConnection connection = OpenConnection()) return connection.State == ConnectionState.Open;
        }

        private static OleDbConnection OpenConnection()
        {
            string path = LocateDatabase();
            Exception lastError = null;
            foreach (string provider in new[] { "Microsoft.ACE.OLEDB.16.0", "Microsoft.ACE.OLEDB.12.0" })
            {
                OleDbConnection connection = new OleDbConnection("Provider=" + provider + ";Data Source=" + path + ";Persist Security Info=False;");
                try
                {
                    connection.Open();
                    ValidateTable(connection);
                    return connection;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                    connection.Dispose();
                }
            }
            throw new InvalidOperationException("Could not open Users.accdb. Confirm that the 64-bit Microsoft Access Database Engine is installed, the project targets x64. " + (lastError == null ? "Unknown provider error." : lastError.Message), lastError);
        }

        private static void ValidateTable(OleDbConnection connection)
        {
            DataTable columns = connection.GetSchema("Columns", new[] { null, null, "Users", null });
            string[] required = { "UserID", "FirstName", "LastName", "Username", "PasswordHash", "CreatedAt" };
            foreach (string name in required)
            {
                bool found = false;
                foreach (DataRow row in columns.Rows)
                    if (string.Equals(Convert.ToString(row["COLUMN_NAME"]), name, StringComparison.OrdinalIgnoreCase)) found = true;
                if (!found) throw new InvalidOperationException("The Users table is missing the required column " + name + ". Please use x64 on the top of any cpu");
            }
        }

        public static bool IsUsernameAvailable(string username)
        {
            using (OleDbConnection connection = OpenConnection())
            using (OleDbCommand command = new OleDbCommand("SELECT COUNT(*) FROM Users WHERE Username = ?", connection))
            {
                command.Parameters.Add("username", OleDbType.VarWChar, 50).Value = username;
                return Convert.ToInt32(command.ExecuteScalar()) == 0;
            }
        }

        public static void CreateAccount(string firstName, string lastName, string username, string password)
        {
            using (OleDbConnection connection = OpenConnection())
            using (OleDbTransaction transaction = connection.BeginTransaction())
            {
                try
                {
                    using (OleDbCommand check = new OleDbCommand("SELECT COUNT(*) FROM Users WHERE Username = ?", connection, transaction))
                    {
                        check.Parameters.Add("username", OleDbType.VarWChar, 50).Value = username;
                        if (Convert.ToInt32(check.ExecuteScalar()) > 0) throw new InvalidOperationException("That username is already registered. Choose another username.");
                    }
                    using (OleDbCommand command = new OleDbCommand("INSERT INTO Users (FirstName, LastName, Username, PasswordHash, CreatedAt) VALUES (?, ?, ?, ?, ?)", connection, transaction))
                    {
                        command.Parameters.Add("firstName", OleDbType.VarWChar, 50).Value = firstName;
                        command.Parameters.Add("lastName", OleDbType.VarWChar, 50).Value = lastName;
                        command.Parameters.Add("username", OleDbType.VarWChar, 50).Value = username;
                        command.Parameters.Add("passwordHash", OleDbType.VarWChar, 64).Value = HashPassword(password);
                        command.Parameters.Add("createdAt", OleDbType.Date).Value = DateTime.Now;
                        command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
                catch
                {
                    try { transaction.Rollback(); } catch { }
                    throw;
                }
            }
        }

        public static UserAccount Authenticate(string username, string password)
        {
            using (OleDbConnection connection = OpenConnection())
            using (OleDbCommand command = new OleDbCommand("SELECT UserID, FirstName, LastName, Username, PasswordHash FROM Users WHERE Username = ?", connection))
            {
                command.Parameters.Add("username", OleDbType.VarWChar, 50).Value = username;
                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    if (!reader.Read()) return null;
                    string stored = Convert.ToString(reader["PasswordHash"]);
                    if (!FixedTimeEquals(stored, HashPassword(password))) return null;
                    return new UserAccount { UserId = Convert.ToInt32(reader["UserID"]), FirstName = Convert.ToString(reader["FirstName"]), LastName = Convert.ToString(reader["LastName"]), Username = Convert.ToString(reader["Username"]) };
                }
            }
        }

        private static bool FixedTimeEquals(string left, string right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;
            int difference = 0;
            for (int i = 0; i < left.Length; i++) difference |= left[i] ^ right[i];
            return difference == 0;
        }

        private static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder result = new StringBuilder(hash.Length * 2);
                foreach (byte value in hash) result.Append(value.ToString("x2"));
                return result.ToString();
            }
        }
    }
}
