using System;
using System.Windows.Forms;

namespace Angelo
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
            registerButton.Click += registerButton_Click;
            loginLink.LinkClicked += loginLink_LinkClicked;
            AcceptButton = registerButton;
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            string firstName = firstNameTextBox.Text.Trim();
            string lastName = lastNameTextBox.Text.Trim();
            string username = usernameTextBox.Text.Trim();
            string password = passwordTextBox.Text;
            string confirmPassword = confirmPasswordTextBox.Text;
            if (firstName.Length == 0 || lastName.Length == 0 || username.Length == 0 || password.Length == 0 || confirmPassword.Length == 0)
            {
                MessageBox.Show("Complete all fields before registering.", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (firstName.Length > 50 || lastName.Length > 50 || username.Length > 50)
            {
                MessageBox.Show("Names and username must contain 50 characters or fewer.", "Input too long", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (password.Length < 6)
            {
                MessageBox.Show("Password must contain at least 6 characters.", "Weak password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!string.Equals(password, confirmPassword, StringComparison.Ordinal))
            {
                MessageBox.Show("The passwords do not match.", "Password mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                confirmPasswordTextBox.Clear();
                confirmPasswordTextBox.Focus();
                return;
            }
            try
            {
                Database.CreateAccount(firstName, lastName, username, password);
                MessageBox.Show("Your account has been created. You can now log in.", "Registration complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Registration failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Database connection", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loginLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
        }
    }
}
