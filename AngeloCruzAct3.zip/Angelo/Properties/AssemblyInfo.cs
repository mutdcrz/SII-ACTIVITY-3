using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Angelo")]
[assembly: AssemblyDescription("Angelo Windows Forms application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Angelo")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("56e31da6-9d01-4550-8b2a-58905e190821")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
