using System;
using System.Windows.Forms;

namespace Angelo
{
    public partial class Dashboard : Form
    {
        private readonly UserAccount currentUser;

        public Dashboard(UserAccount user)
        {
            if (user == null) throw new ArgumentNullException("user");
            currentUser = user;
            InitializeComponent();
            string displayName = (currentUser.FirstName + " " + currentUser.LastName).Trim();
            if (displayName.Length == 0) displayName = currentUser.Username;
            welcomeLabel.Text = "Welcome, " + displayName + "!";
            logoutButton.Click += logoutButton_Click;
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void accentPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void welcomeCardPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
