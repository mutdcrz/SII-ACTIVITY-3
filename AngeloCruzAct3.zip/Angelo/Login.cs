using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace Angelo
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            string logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "AngeloLogo.png");
            if (File.Exists(logoPath)) logoPictureBox.Image = Image.FromFile(logoPath);
            loginButton.Click += loginButton_Click;
            signUpLink.LinkClicked += signUpLink_LinkClicked;
            AcceptButton = loginButton;
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text.Trim();
            string password = passwordTextBox.Text;
            if (username.Length == 0 || password.Length == 0)
            {
                MessageBox.Show("Enter your username and password.", "Missing information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                UserAccount user = Database.Authenticate(username, password);
                if (user == null)
                {
                    MessageBox.Show("The username or password is incorrect.", "Login failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    passwordTextBox.Clear();
                    passwordTextBox.Focus();
                    return;
                }
                Hide();
                using (Dashboard dashboard = new Dashboard(user)) dashboard.ShowDialog();
                passwordTextBox.Clear();
                Show();
                Activate();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Database connection", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void signUpLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (SignUp form = new SignUp())
            {
                Hide();
                form.ShowDialog();
                Show();
                Activate();
            }
            usernameTextBox.Focus();
        }
    }
}
